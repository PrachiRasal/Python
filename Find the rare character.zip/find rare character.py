with open("challeng3.txt","r") as fh:
    content = fh.read()
    set1=set(content)
    dict1={}
    
    for x in set1:
        count=0
        count=content.count(x)
        dict1.update([(x,count)])
        fh.seek(0)
        
    print(dict1)
    mincount=min(dict1.values())
    list1=list()
    for keys,values in dict1.items():
        if values==mincount:
            list1.append(keys)

    print ("".join(list1))
