#Guess the movie

import random

##Open the file of movie lists
def readfile():
    f=open(r"D:\Prachi\Python Scripts\movies.txt", "r")
    input_file=f.read()
    input_val=list(input_file.replace("'",'').split(','))
    ##read a random movie name from the list
    Movie_name=(random.choice(input_val).lower())
    return Movie_name


##Hinding the Movie Name
def hide(Movie_name):
    x=0
    letters=list(Movie_name)
    hide_letters=[]
    while x < len(letters):
        if letters[x]!=' ':
           hide_letters.append('*')                 ## displays * in place of letters of movie name
        else:
            hide_letters.append(' ')
        x+=1
    word=''.join(hide_letters)
    print('\nMovie Name is: ', word)
    return hide_letters


##Number of vowels present
def vowels(Movie_name):
    vowels=['a','e','i','o']
    letters=list(Movie_name)
    count=0
    for i in vowels:
        x=0
        while x < len(letters):
            if letters[x] == i :
                count+=1
                x+=1
            else:
                x+=1
    print('\nVowels present in ', count,' places')
    

##guess the words
def game(hide_letters,Movie_name):
    word=''.join(hide_letters)
    counter=10
    entry=[]
    letters=list(Movie_name)
    while counter > 0:
        if word!=Movie_name:
            print('\nNumber attempts available=', counter)
            print('letters entered till now: ', entry)
            print('\nGuess the letter :')
            letter=input()
            if letter in entry:
                print('Letter is already entered!')
            else:
                entry.append(letter)
                if letter in letters:
                    pos=[]
                    offset=-1
                    while offset < len(letters):
                        try:
                            ind=letters.index(letter,offset+1)
                            pos.append(ind)
                            offset=ind
                        except:
                            break  
                    for i in pos:
                        hide_letters[i]=letters[i]
                        word=''.join(hide_letters)
                    print('\nMovie :', word)
                else:
                    counter-=1
                    if counter==0:
                        print('Game Over!!\nMovie Name : ',Movie_name)
                        break
        else:
            print('\nBravo!!')
            break



##Execute game
def exegame():
    Movie_name=readfile()
    hide_letters=hide(Movie_name)
    vowels(Movie_name)
    game(hide_letters,Movie_name)
    

##Keep Playing
def playagain():
    print('\n\nYou want play again? \n1.Yes \n2.No')
    ans=input()
    if ans=='1':
        exegame()
    else:
        print('\nBye!!')
        return
    

##User input
print('Your Name :')
Name=input()
print('\nHi', Name,', want to play a game?\n 1. Yes \n 2. No \n')
ans=input()

if ans=='1':
    print('\nGuess the Movie Name.... \nRules: \n1. One letter at a time \n2. For every wrong guess ! attempt will reduce.')
    exegame()
    playagain()
else:
    print('\nBye!!')


        

